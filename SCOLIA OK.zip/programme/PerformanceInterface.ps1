﻿if(-not (Get-Command Import-ITMCompiledSource -ErrorAction SilentlyContinue)){. (Join-Path $PSScriptRoot 'CompilationCache.ps1')}
if(-not ('ITMActivity' -as [type])){Import-ITMCompiledSource -Path (Join-Path $PSScriptRoot 'ActivityIndicator.cs') -ReferencedAssemblies System.Windows.Forms,System.Drawing}
$script:activity=$null;$script:activityDepth=0;$script:activitySource=$null
$script:learnerIndex=@();$script:dataRevision=0;$script:learnerStamp='';$script:payLearnerStamp=''
$script:pendingLearnerSearch=$false;$script:pendingPaySearch=$false
$script:searchTimer=New-Object Windows.Forms.Timer;$script:searchTimer.Interval=140 # Filtrage quasi instantane sans recalculer la grille a chaque touche.
function Get-ITMActivityAnchor {
    $owner=[Windows.Forms.Form]::ActiveForm;if(-not $owner){$owner=$script:main}
    if($script:activitySource -and -not $script:activitySource.IsDisposed -and $script:activitySource.Visible -and $script:activitySource.FindForm() -eq $owner){return $script:activitySource}
    $control=$owner.ActiveControl
    while($control -is [Windows.Forms.ContainerControl] -and $control.ActiveControl){$control=$control.ActiveControl}
    if($control -is [Windows.Forms.ButtonBase] -and $control.Visible){return $control}
    return $owner
}
function Start-ITMActivity([string]$message,$anchor=$null) {
    $script:activityDepth++
    try{
    # Réutiliser la carte du parcours de démarrage : pas de deux roues simultanées.
    if($global:ScoliaTransitionVisual){Update-ScoliaTransition $message;return}
    if($script:activity){$script:activity.Update($message);return}
    if(-not $anchor -or $anchor.IsDisposed){$anchor=Get-ITMActivityAnchor}
    $owner=$anchor.FindForm()
    if(-not $owner){$owner=$script:main}
    $script:activityAnchor=$anchor;$script:activityAnchorText=$null
    # L'indicateur moderne ne remplace plus le texte du bouton : aucune rupture visuelle.
    $bounds=$anchor.RectangleToScreen($anchor.ClientRectangle)
    $ownerBounds=$owner.RectangleToScreen($owner.ClientRectangle)
    $q=[Math]::Max(1,$owner.CurrentAutoScaleDimensions.Height/96.0)
    $cardHeight=[int][Math]::Min(144*$q,[Math]::Max(40,$ownerBounds.Height-20*$q))
    $cardWidth=[int][Math]::Max(100,[Math]::Min(440*$q,$ownerBounds.Width-(24*$q)))
    $left=[int]($ownerBounds.Left+($ownerBounds.Width-$cardWidth)/2)
    $top=[int]($ownerBounds.Bottom-$cardHeight-(22*$q))
    if($anchor -is [Windows.Forms.ButtonBase]){
        $left=[int]($bounds.Left+($bounds.Width-$cardWidth)/2)
        $left=[Math]::Max($ownerBounds.Left+[int](12*$q),[Math]::Min($left,$ownerBounds.Right-$cardWidth-[int](12*$q)))
        $above=[int]($bounds.Top-$cardHeight-(10*$q));$below=[int]($bounds.Bottom+(10*$q))
        if($above -ge $ownerBounds.Top+[int](10*$q)){$top=$above}elseif($below+$cardHeight -le $ownerBounds.Bottom-[int](10*$q)){$top=$below}
    }
    $top=[Math]::Max($ownerBounds.Top+[int](10*$q),[Math]::Min($top,$ownerBounds.Bottom-$cardHeight-[int](10*$q)))
    $rect=New-Object Drawing.Rectangle($left,$top,$cardWidth,$cardHeight)
    $handle=$(if($owner -and $owner.Visible){$owner.Handle}else{[IntPtr]::Zero})
    $dark=$(if(Get-Command Get-ITMEffectiveDarkTheme -ErrorAction SilentlyContinue){Get-ITMEffectiveDarkTheme}else{$false})
    $script:activity=New-Object ITMActivity($message,$rect,$handle,$script:windowIconPath,$dark)
    }catch{
        # Visual setup is auxiliary. Keep this call's depth until its matching Stop.
        Clear-ITMActivityVisual
    }
}
function Clear-ITMActivityVisual {
    try{if($script:activity){$script:activity.Dispose()}}catch{}
    finally{
        $script:activity=$null
        try{if($null -ne $script:activityAnchorText -and $script:activityAnchor -and -not $script:activityAnchor.IsDisposed){$script:activityAnchor.Text=$script:activityAnchorText}}catch{}
        finally{$script:activityAnchor=$null;$script:activityAnchorText=$null}
    }
}
function Stop-ITMActivity {
    $script:activityDepth=[Math]::Max(0,$script:activityDepth-1)
    if($script:activityDepth -eq 0){Clear-ITMActivityVisual}
}
function Set-ITMActivityMessage([string]$message) {
    if($global:ScoliaTransitionVisual){Update-ScoliaTransition $message;return}
    if($script:activity){$script:activity.Update($message)}
}
function Get-ITMBalanceKey([string]$mat,[string]$month) {
    return [string]::Format('{0}::{1}',(Key $mat),(Key $month))
}
function Schedule-ITMSearch([string]$target) {
    if($script:loading -or $script:busy){return}
    if($target -eq 'Learners'){$script:pendingLearnerSearch=$true}else{$script:pendingPaySearch=$true;$script:payLearnerGrid.Enabled=$false;$script:payLearnerGrid.ClearSelection()}
    $script:searchTimer.Stop();$script:searchTimer.Start()
}
$script:searchTimer.Add_Tick({
    if($script:busy -or $script:loading){return}
    $script:searchTimer.Stop()
    try{
        if($script:pendingLearnerSearch){$script:pendingLearnerSearch=$false;Refresh-Learners 'Learners'}
        if($script:pendingPaySearch){$script:pendingPaySearch=$false;Refresh-Learners 'Payments';Refresh-Payments}
    }catch{App-Error $_}finally{$script:payLearnerGrid.Enabled=[bool]$script:book}
})
function Rebuild-ITMLearnerIndex {
    if(Get-Command Sync-ScoliaDisciplineSnapshot -ErrorAction SilentlyContinue){[void](Sync-ScoliaDisciplineSnapshot)}
    $index=New-Object 'System.Collections.Generic.List[object]'
    foreach($row in @($script:data.learners | Sort-Object Promotion,Nom,PostNom,Prenom)){
        $index.Add([pscustomobject]@{Entry=$row;Text=(Key ($row.Matricule+' '+$row.Nom+' '+$row.PostNom+' '+$row.Prenom+' '+$row.Promotion));Promotion=(Promo $row.Promotion)})
    }
    $script:learnerIndex=$index.ToArray();$script:dataRevision++
}

function Apply-ITMLearnerSlice($slice) {
    if(-not $slice -or -not $slice.PSObject.Properties['ok'] -or -not $slice.ok){throw 'Actualisation ciblée invalide.'}
    $mat=Key ([string]$slice.matricule)
    if(-not $mat){throw 'Matricule absent dans l actualisation ciblée.'}
    # Remplace uniquement le dossier concerné et son historique. Les promotions,
    # paramètres, diagnostics et autres dossiers ne sont pas relus depuis Excel.
    $learners=New-Object 'System.Collections.Generic.List[object]'
    foreach($row in @($script:data.learners)){if((Key $row.Matricule) -ne $mat){$learners.Add($row)}}
    if($slice.PSObject.Properties['learner'] -and $slice.learner){$learners.Add($slice.learner)}
    $script:data.learners=$learners.ToArray()

    $payments=New-Object 'System.Collections.Generic.List[object]'
    foreach($row in @($script:data.payments)){if((Key $row.Matricule) -ne $mat){$payments.Add($row)}}
    foreach($row in @($slice.payments)){if($row){$payments.Add($row)}}
    $script:data.payments=$payments.ToArray()

    $balances=New-Object 'System.Collections.Generic.List[object]'
    foreach($row in @($script:data.balances)){if((Key $row.Matricule) -ne $mat){$balances.Add($row)}}
    foreach($row in @($slice.balances)){if($row){$balances.Add($row)}}
    $script:data.balances=$balances.ToArray()

    Rebuild-ITMLearnerIndex
    foreach($key in @($script:balance.Keys)){if($key.StartsWith($mat+'::',[StringComparison]::Ordinal)){$script:balance.Remove($key)}}
    foreach($b in @($slice.balances)){
        $balanceKey=Get-ITMBalanceKey $b.Matricule $b.Mois
        $script:balance[$balanceKey]=[decimal]$b.Verse
    }
    $script:learnerStamp='';$script:payLearnerStamp='';$script:snapshotValid=$true;$script:payNeedsRefresh=$false
    if($null -eq $script:viewRevision){$script:viewRevision=@{}}else{
        foreach($name in @('Tableau de bord','Apprenants','Paiements','Scolarité','Diagnostic')){if($script:viewRevision.ContainsKey($name)){$script:viewRevision.Remove($name)}}
    }
}
function Update-ITMAfterWrite([string]$mat,[bool]$deferView=$false) {
    # La tranche renvoyée par la passerelle évite les relectures complètes du classeur.
    # Les promotions et les mois ne changent pas pendant une inscription ou un paiement :
    # ne pas reconstruire leurs listes à chaque sauvegarde évite du travail UI inutile.
    try{
        $slice=$script:lastLearnerSlice;$script:lastLearnerSlice=$null
        if(-not $slice -or (Key $slice.matricule) -ne (Key $mat)){$slice=Invoke-ITMJsonDirect 'ITMAppEtatApprenant' @($mat)}
        Apply-ITMLearnerSlice $slice
        if($script:scolia){$script:scoliaRosterPending=$true}
        if(-not $deferView){Refresh-ITMCurrentPage}
        Update-WorkspaceState
        return $true
    }catch{
        $script:lastLearnerSlice=$null
        # Compatibilité sûre avec un ancien classeur : une seule relecture complète en secours.
        Refresh-Data $deferView
        return $false
    }
}

function Update-ITMLearnerLayout($panel) {
    if(-not $script:learnerActions){return}
    $q=[Math]::Max(1,[Math]::Min(2.5,$script:main.CurrentAutoScaleDimensions.Height/96))
    $margin=[int](16*$q);$gap=[int](8*$q);$width=[Math]::Max(60,$panel.ClientSize.Width-2*$margin-[Windows.Forms.SystemInformation]::VerticalScrollBarWidth)
    $y=[int](14*$q)
    Set-ITMAdaptiveFont $script:learnerHint 10 ([Drawing.FontStyle]::Regular)
    $hh=Get-ITMTextHeight $script:learnerHint $width ([int](30*$q));$script:learnerHint.SetBounds($margin,$y,$width,$hh);$y+=$hh+$gap
    $surfaceTop=$y-[int](12*$q)
    $two=$width -ge 740*$q
    $searchWidth=$(if($two){[int]($width*0.58)}else{$width})
    $labelH=Get-ITMTextHeight $script:learnerSearchLabel $searchWidth ([int](24*$q))
    $fieldH=[Math]::Max([int](32*$q),$script:search.PreferredSize.Height)
    $script:learnerSearchLabel.SetBounds($margin,$y,$searchWidth,$labelH)
    $script:search.SetBounds($margin,($y+$labelH),$searchWidth,$fieldH)
    if($two){$x=$margin+$searchWidth+$gap;$comboWidth=$width-$searchWidth-$gap;$promoY=$y}else{$x=$margin;$comboWidth=$width;$promoY=$script:search.Bottom+$gap}
    $promoLabelH=Get-ITMTextHeight $script:learnerPromotionLabel $comboWidth ([int](24*$q))
    $script:learnerPromotionLabel.SetBounds($x,$promoY,$comboWidth,$promoLabelH)
    $comboH=[Math]::Max([int](32*$q),$script:filterPromo.PreferredSize.Height)
    $script:filterPromo.SetBounds($x,($promoY+$promoLabelH),$comboWidth,$comboH)
    $y=[Math]::Max($script:search.Bottom,$script:filterPromo.Bottom)+$gap
    $stack=$width/$q -lt 600
    $resetWidth=$(if($stack){$width}else{[Math]::Min([int](230*$q),[int]($width*.40))})
    $countWidth=$(if($stack){$width}else{$width-$resetWidth-$gap})
    $h=Get-ITMTextHeight $script:countLabel $countWidth ([int](30*$q));$script:countLabel.SetBounds($margin,$y,$countWidth,$h)
    $resetY=$(if($stack){$script:countLabel.Bottom+$gap}else{$y});$resetX=$(if($stack){$margin}else{$margin+$width-$resetWidth})
    $h=Get-ITMTextHeight $script:learnerReset $resetWidth ([int](38*$q));$script:learnerReset.SetBounds($resetX,$resetY,$resetWidth,$h)
    $y=[Math]::Max($script:countLabel.Bottom,$script:learnerReset.Bottom)+$gap
    $toolbarX=$margin;$toolbarY=$y;$rowHeight=0
    foreach($button in $script:learnerActions){
        Set-ITMAdaptiveFont $button 9.5 ([Drawing.FontStyle]::Regular)
        $textSize=[Windows.Forms.TextRenderer]::MeasureText($button.Text,$button.Font)
        $bw=[Math]::Min($width,[Math]::Max([int](130*$q),$textSize.Width+[int](32*$q)))
        $bh=Get-ITMTextHeight $button $bw ([int](38*$q))
        if($toolbarX -gt $margin -and $toolbarX+$bw -gt $margin+$width){$toolbarY+=$rowHeight+$gap;$toolbarX=$margin;$rowHeight=0}
        $button.SetBounds($toolbarX,$toolbarY,$bw,$bh);$toolbarX+=$bw+$gap;$rowHeight=[Math]::Max($rowHeight,$bh)
    }
    $y=$toolbarY+$rowHeight+[int](12*$q)
    $script:learnerSurface.Visible=$false
    $height=[Math]::Max([int](240*$q),$panel.ClientSize.Height-$y-[int](24*$q))
    $script:learnersGrid.SetBounds($margin,$y,$width,$height)
    Set-ITMGridReadability $script:learnersGrid
    $panel.AutoScrollMinSize=New-Object Drawing.Size(0,($y+$height+[int](24*$q)))
}

# Hidden views are redrawn when opened, from the verified current snapshot.
$script:viewRevision=@{};$script:snapshotValid=$false
function Test-ITMPageNeedsRefresh([string]$name){
    if(-not $name -or -not $script:data){return $false}
    if($name -eq 'Tableau de bord' -and $script:dashboardDate -ne (Get-Date).ToString('yyyyMMdd')){return $true}
    return ($null -eq $script:viewRevision -or -not $script:viewRevision.ContainsKey($name) -or $script:viewRevision[$name] -ne $script:dataRevision)
}
function Refresh-ITMCurrentPage {
    $name=[string]$script:currentPage
    if(-not $name -or -not $script:data){return}
    if($null -eq $script:viewRevision){$script:viewRevision=@{}}
    if(-not (Test-ITMPageNeedsRefresh $name)){return}
    switch($name){
        'Comptabilité' {Refresh-ScoliaFinance}
        'Apprenants' {Refresh-Learners 'Learners'}
        'Paiements' {
            Refresh-Learners 'Payments'
            if($script:payMat){
                $current=@($script:data.learners | Where-Object {$_.Eligible -and (Key $_.Matricule) -eq (Key $script:payMat)})
                if($current.Count -eq 1){Choose-Payment $script:payMat}else{Reset-PaymentSelection}
            }else{Refresh-Payments}
        }
        'Tableau de bord' {Refresh-Dashboard}
        'Administration' {Refresh-Administration}
        'Exports' {Refresh-ITMSchoolCards}
        'Données' {Refresh-ITMDataPage}
        'Diagnostic' {
            Set-Grid $script:issuesGrid @($script:data.issues) @(@('Feuille','Feuille'),@('Ligne','Ligne'),@('Matricule','Matricule'),@('Numero','N°'),@('Observation','Observation'))
            $script:issuesLabel.Text="$(@($script:data.issues).Count) observation(s) de qualité des données. Aucun rapprochement automatique des fragments de paiement."
        }
    }
    $script:viewRevision[$name]=$script:dataRevision
}
